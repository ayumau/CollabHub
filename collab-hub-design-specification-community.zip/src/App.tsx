import React, { useState } from 'react';
import { VideoPanel } from './components/VideoPanel';
import { ChatPanel } from './components/ChatPanel';
import { CanvasPanel } from './components/CanvasPanel';
import { AccessibilityBar } from './components/AccessibilityBar';
import { UserPresence } from './components/UserPresence';
import { DesignSpecification } from './components/DesignSpecification';
import { CollabHubPoster } from './components/CollabHubPoster';
import { Video, MessageSquare, Palette } from 'lucide-react';
import { ViewSwitcher, type ViewMode } from './components/ViewSwitcher';

/**
 * CollabHub: Accessibility-First Collaborative Workspace
 * 
 * DESIGN PRINCIPLES:
 * 1. Zero Context Switching: All tools visible simultaneously in optimized layout
 * 2. Accessibility First: Designed for deaf/HoH users with visual indicators throughout
 * 3. Creative Momentum: Seamless transitions maintain flow state
 * 4. Universal Presence: User awareness across all mediums simultaneously
 * 
 * LAYOUT ARCHITECTURE:
 * - Left: Video (25%) - Persistent presence awareness
 * - Center: Canvas (50%) - Primary creative workspace
 * - Right: Chat (25%) - Communication without interruption
 * - Top: Accessibility controls always available
 * - Bottom: Shared user presence indicators
 */

export default function App() {
  const [activeFeature, setActiveFeature] = useState<'video' | 'chat' | 'canvas' | null>(null);
  const [captionsEnabled, setCaptionsEnabled] = useState(true);
  const [visualIndicators, setVisualIndicators] = useState(true);
  const [layoutMode, setLayoutMode] = useState<'default' | 'focus-canvas' | 'focus-video'>('default');
  const [viewMode, setViewMode] = useState<ViewMode>('prototype');

  return (
    <div className="h-screen w-screen flex flex-col bg-background text-foreground overflow-hidden">
      {/* View switcher - floats only over the document views; in the workspace it lives in the top bar */}
      {viewMode !== 'prototype' && (
        <div className="fixed top-4 right-5 z-50 rounded-full bg-card/80 backdrop-blur-xl shadow-float">
          <ViewSwitcher value={viewMode} onChange={setViewMode} />
        </div>
      )}

      {viewMode === 'poster' ? (
        <CollabHubPoster />
      ) : viewMode === 'specification' ? (
        <DesignSpecification />
      ) : (
        <>
          {/* Accessibility Bar - Always visible, sticky top */}
          <AccessibilityBar 
            captionsEnabled={captionsEnabled}
            setCaptionsEnabled={setCaptionsEnabled}
            visualIndicators={visualIndicators}
            setVisualIndicators={setVisualIndicators}
            layoutMode={layoutMode}
            setLayoutMode={setLayoutMode}
            viewSwitcher={<ViewSwitcher value={viewMode} onChange={setViewMode} />}
          />

          {/* Main Collaboration Space - No context switching */}
          <main className="flex-1 flex gap-4 p-4 overflow-hidden">
            {/* Video Panel - Left column, persistent presence */}
            <section
              aria-label="Video"
              className={`
                ${layoutMode === 'focus-canvas' ? 'w-[15%]' : 'w-[25%]'} 
                ${layoutMode === 'focus-video' ? 'w-[40%]' : ''}
                transition-all duration-300 ease-in-out
                flex flex-col rounded-2xl
                ${activeFeature === 'video' && visualIndicators ? 'ring-2 ring-signal-video/70 ring-offset-2 ring-offset-background' : ''}
              `}
              onMouseEnter={() => setActiveFeature('video')}
              onMouseLeave={() => setActiveFeature(null)}
            >
              <VideoPanel 
                visualIndicators={visualIndicators}
                captionsEnabled={captionsEnabled}
              />
            </section>

            {/* Canvas Panel - Center, primary workspace */}
            <section
              aria-label="Canvas"
              className={`
                ${layoutMode === 'focus-canvas' ? 'flex-1' : 'w-[50%]'}
                ${layoutMode === 'focus-video' ? 'w-[35%]' : ''}
                transition-all duration-300 ease-in-out
                flex flex-col rounded-2xl
                ${activeFeature === 'canvas' && visualIndicators ? 'ring-2 ring-signal-canvas/70 ring-offset-2 ring-offset-background' : ''}
              `}
              onMouseEnter={() => setActiveFeature('canvas')}
              onMouseLeave={() => setActiveFeature(null)}
            >
              <CanvasPanel />
            </section>

            {/* Chat Panel - Right column, persistent communication */}
            <section
              aria-label="Chat"
              className={`
                w-[25%] 
                ${layoutMode === 'focus-canvas' ? 'w-[20%]' : ''}
                ${layoutMode === 'focus-video' ? 'w-[25%]' : ''}
                transition-all duration-300 ease-in-out
                flex flex-col rounded-2xl
                ${activeFeature === 'chat' && visualIndicators ? 'ring-2 ring-signal-chat/70 ring-offset-2 ring-offset-background' : ''}
              `}
              onMouseEnter={() => setActiveFeature('chat')}
              onMouseLeave={() => setActiveFeature(null)}
            >
              <ChatPanel visualIndicators={visualIndicators} />
            </section>
          </main>

          {/* Universal Presence Bar - Shows activity across all mediums */}
          <UserPresence />

          {/* Visual Feature Indicator - Accessibility enhancement */}
          {visualIndicators && activeFeature && (
            <div
              role="status"
              aria-live="polite"
              className="fixed top-16 left-1/2 -translate-x-1/2 bg-card/90 backdrop-blur-xl px-4 py-2 rounded-full shadow-float z-50 animate-in fade-in slide-in-from-top-2 duration-200"
            >
              <div className="flex items-center gap-2 text-sm font-medium">
                {activeFeature === 'video' && (
                  <>
                    <Video className="size-4 text-signal-video" />
                    <span>Video Panel Active</span>
                  </>
                )}
                {activeFeature === 'chat' && (
                  <>
                    <MessageSquare className="size-4 text-signal-chat" />
                    <span>Chat Panel Active</span>
                  </>
                )}
                {activeFeature === 'canvas' && (
                  <>
                    <Palette className="size-4 text-signal-canvas" />
                    <span>Canvas Panel Active</span>
                  </>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
