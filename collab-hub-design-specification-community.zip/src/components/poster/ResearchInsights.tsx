import React from 'react';
import { Eye, Hand, CheckCircle2, ArrowRightLeft, Volume2 } from 'lucide-react';

/**
 * Research Key Insights Section
 * Highlights accessibility research findings and design solutions
 */
export function ResearchInsights() {
  return (
    <div className="flex flex-col gap-8">
      <h2 className="text-2xl font-semibold tracking-tight border-b border-border pb-4">
        Research Key Insights
      </h2>

      {/* Core Finding */}
      <div className="bg-muted rounded-xl p-5 ring-1 ring-tint/40">
        <h3 className="text-lg font-semibold tracking-tight mb-2">
          Core Discovery
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Context switching isn&apos;t just an inconvenience—it&apos;s an accessibility barrier. When video conferencing requires ASL communication, users cannot simultaneously annotate shared documents or reference chat without losing visual contact with collaborators.
        </p>
      </div>

      {/* Key Research Findings */}
      <div className="flex flex-col gap-3">
        <h3 className="text-lg font-semibold tracking-tight">WCAG 2.1 Level AA Requirements</h3>
        <ul className="flex flex-col gap-2.5">
          <li className="flex items-start gap-2.5">
            <CheckCircle2 className="size-4 text-tint mt-0.5 flex-shrink-0" />
            <p className="text-xs text-muted-foreground leading-relaxed">
              <strong className="text-foreground font-semibold">Visual Indicators:</strong> All audio cues replaced with visual equivalents (color-coded borders, notification badges, screen flashes)
            </p>
          </li>
          <li className="flex items-start gap-2.5">
            <CheckCircle2 className="size-4 text-tint mt-0.5 flex-shrink-0" />
            <p className="text-xs text-muted-foreground leading-relaxed">
              <strong className="text-foreground font-semibold">ASL-Optimized Video:</strong> 4:3 or 1:1 aspect ratios (not 16:9) to show hands, face, and upper torso
            </p>
          </li>
          <li className="flex items-start gap-2.5">
            <CheckCircle2 className="size-4 text-tint mt-0.5 flex-shrink-0" />
            <p className="text-xs text-muted-foreground leading-relaxed">
              <strong className="text-foreground font-semibold">Live Captions:</strong> Real-time captions positioned below video with speaker identification
            </p>
          </li>
          <li className="flex items-start gap-2.5">
            <CheckCircle2 className="size-4 text-tint mt-0.5 flex-shrink-0" />
            <p className="text-xs text-muted-foreground leading-relaxed">
              <strong className="text-foreground font-semibold">Contrast Ratios:</strong> 4.5:1 for text, 3:1 for UI components ensuring visibility
            </p>
          </li>
        </ul>
      </div>

      {/* Critical Pain Points Identified */}
      <div className="flex flex-col gap-3">
        <h3 className="text-lg font-semibold tracking-tight">Critical Pain Points Identified</h3>
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-muted rounded-xl p-4 flex flex-col items-center gap-2 text-center">
            <ArrowRightLeft className="size-6 text-tint" />
            <div className="text-xs text-foreground font-medium">Context Switching</div>
          </div>
          <div className="bg-muted rounded-xl p-4 flex flex-col items-center gap-2 text-center">
            <Volume2 className="size-6 text-tint" />
            <div className="text-xs text-foreground font-medium">Audio-Centric Design</div>
          </div>
          <div className="bg-muted rounded-xl p-4 flex flex-col items-center gap-2 text-center">
            <Eye className="size-6 text-tint" />
            <div className="text-xs text-foreground font-medium">Poor Video Layouts</div>
          </div>
          <div className="bg-muted rounded-xl p-4 flex flex-col items-center gap-2 text-center">
            <Hand className="size-6 text-tint" />
            <div className="text-xs text-foreground font-medium">No ASL Expression</div>
          </div>
        </div>
      </div>

      {/* Solution Insights */}
      <div className="flex flex-col gap-3">
        <h3 className="text-lg font-semibold tracking-tight">CollabHub Solution Insights</h3>
        <div className="flex flex-col gap-2">
          <div className="bg-muted rounded-xl p-4">
            <p className="text-xs text-foreground font-semibold mb-1">
              Unified Interface (25% | 50% | 25%)
            </p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Video, canvas, and chat visible simultaneously—no tab switching required
            </p>
          </div>
          <div className="bg-muted rounded-xl p-4">
            <p className="text-xs text-foreground font-semibold mb-1">
              Hand-Signed Emoji System
            </p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              MediaPipe recognizes ASL gestures, converting them to culturally authentic animated emojis
            </p>
          </div>
          <div className="bg-muted rounded-xl p-4">
            <p className="text-xs text-foreground font-semibold mb-1">
              Visual-First Notifications
            </p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Color-coded active speaker borders, notification badges, screen flashes for urgent alerts
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
