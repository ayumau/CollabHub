import React from 'react';
import { Palette, Video, MessageSquare } from 'lucide-react';

/**
 * Process & Prototypes Section
 * Showcases CollabHub's implementation and key features
 */
export function ProcessPrototypes() {
  return (
    <div className="flex flex-col gap-8">
      <h2 className="text-2xl font-semibold tracking-tight border-b border-border pb-4">
        Process &amp; Prototypes
      </h2>

      {/* Prototype 1: Three-Panel Layout */}
      <div className="flex flex-col gap-3">
        <h3 className="text-sm font-semibold">
          <span className="text-muted-foreground font-medium">Prototype 1 · </span>Unified Three-Panel Interface
        </h3>
        <div className="bg-muted rounded-xl p-3">
          <div className="flex gap-1.5 h-28">
            <div className="flex-[25] bg-card rounded-lg ring-1 ring-signal-video/60 flex items-center justify-center">
              <Video className="size-6 text-signal-video" />
            </div>
            <div className="flex-[50] bg-card rounded-lg ring-1 ring-signal-canvas/60 flex items-center justify-center">
              <Palette className="size-6 text-signal-canvas" />
            </div>
            <div className="flex-[25] bg-card rounded-lg ring-1 ring-signal-chat/60 flex items-center justify-center">
              <MessageSquare className="size-6 text-signal-chat" />
            </div>
          </div>
        </div>
        <ul className="text-xs text-muted-foreground flex flex-col gap-1 list-disc pl-4 leading-relaxed">
          <li>Eliminates context switching—all tools visible simultaneously</li>
          <li>25% Video | 50% Canvas | 25% Chat optimal ratio</li>
          <li>Adaptive layouts for focus modes and different tasks</li>
        </ul>
      </div>

      {/* Prototype 2: Hand-Signed Emoji System */}
      <div className="flex flex-col gap-3">
        <h3 className="text-sm font-semibold">
          <span className="text-muted-foreground font-medium">Prototype 2 · </span>Hand-Signed Emoji Recognition
        </h3>
        <div className="bg-muted rounded-xl p-3">
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-card rounded-lg p-3 text-center">
              <div className="text-2xl mb-1 leading-none" aria-hidden="true">👍</div>
              <div className="text-xs text-muted-foreground">Thumbs Up</div>
            </div>
            <div className="bg-card rounded-lg p-3 text-center">
              <div className="text-2xl mb-1 leading-none" aria-hidden="true">🤫</div>
              <div className="text-xs text-muted-foreground">Mute Sign</div>
            </div>
            <div className="bg-card rounded-lg p-3 text-center">
              <div className="text-2xl mb-1 leading-none" aria-hidden="true">😶</div>
              <div className="text-xs text-muted-foreground">Speechless</div>
            </div>
          </div>
        </div>
        <ul className="text-xs text-muted-foreground flex flex-col gap-1 list-disc pl-4 leading-relaxed">
          <li>MediaPipe hand tracking with real-time gesture recognition</li>
          <li>Culturally authentic ASL-based emoji expressions</li>
          <li>0.8–1.0s hold duration for accurate detection</li>
        </ul>
      </div>

      {/* Prototype 3: Visual Accessibility Features */}
      <div className="flex flex-col gap-3">
        <h3 className="text-sm font-semibold">
          <span className="text-muted-foreground font-medium">Prototype 3 · </span>Visual Accessibility System
        </h3>
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3 bg-muted rounded-xl px-4 py-3">
            <div className="size-2.5 rounded-full bg-signal-video shadow-[0_0_0_4px_rgba(64,156,255,0.2)]" />
            <span className="text-xs text-foreground">Active speaker: Blue pulsing border</span>
          </div>
          <div className="flex items-center gap-3 bg-muted rounded-xl px-4 py-3">
            <div className="size-2.5 rounded-full bg-signal-chat shadow-[0_0_0_4px_rgba(48,209,88,0.2)]" />
            <span className="text-xs text-foreground">New message: Green notification badge</span>
          </div>
          <div className="flex items-center gap-3 bg-muted rounded-xl px-4 py-3">
            <div className="size-2.5 rounded-full bg-signal-canvas shadow-[0_0_0_4px_rgba(191,90,242,0.2)]" />
            <span className="text-xs text-foreground">Canvas activity: Purple highlight pulse</span>
          </div>
        </div>
        <ul className="text-xs text-muted-foreground flex flex-col gap-1 list-disc pl-4 leading-relaxed">
          <li>All audio cues converted to visual indicators</li>
          <li>Color-coded participant identification system</li>
          <li>Real-time captions with speaker attribution</li>
        </ul>
      </div>

      {/* Design Iterations */}
      <div className="flex flex-col gap-3">
        <h3 className="text-sm font-semibold">Design Iterations</h3>
        <ol className="bg-muted rounded-xl p-4 flex flex-col gap-2.5 text-xs text-muted-foreground leading-relaxed">
          <li className="flex items-start gap-3">
            <span className="text-tint font-semibold tabular-nums shrink-0">1</span>
            <span><strong className="text-foreground font-semibold">Iteration 1:</strong> Established 25|50|25 panel ratio through user testing with deaf participants</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="text-tint font-semibold tabular-nums shrink-0">2</span>
            <span><strong className="text-foreground font-semibold">Iteration 2:</strong> Implemented adaptive focus modes (canvas-priority, video-priority)</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="text-tint font-semibold tabular-nums shrink-0">3</span>
            <span><strong className="text-foreground font-semibold">Iteration 3:</strong> Added MediaPipe hand tracking with 95%+ gesture accuracy</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="text-tint font-semibold tabular-nums shrink-0">4</span>
            <span><strong className="text-foreground font-semibold">Iteration 4:</strong> Refined visual indicators to meet WCAG 2.1 Level AA standards</span>
          </li>
        </ol>
      </div>
    </div>
  );
}
