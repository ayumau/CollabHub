import React from 'react';
import { AlertCircle, ArrowRightLeft } from 'lucide-react';

/**
 * Problem and Context Section
 * Highlights the critical issues with existing collaboration platforms
 */
export function ProblemContext() {
  return (
    <div className="flex flex-col gap-8">
      <h2 className="text-2xl font-semibold tracking-tight border-b border-border pb-4">
        Problem and Context
      </h2>

      {/* The Problem */}
      <div className="flex flex-col gap-3">
        <h3 className="text-lg font-semibold tracking-tight">The Problem</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Deaf and hard-of-hearing users face significant barriers when using existing collaboration platforms. Current tools force constant context switching, rely heavily on audio-centric design, and lack culturally authentic ways to express emotion through sign language.
        </p>
        <div className="bg-muted p-4 rounded-xl">
          <p className="text-sm text-foreground leading-relaxed">
            <strong className="text-tint font-semibold">Key issue.</strong> Users must juggle 3+ separate applications (Zoom + Figma/Miro + Slack) to accomplish what should be a unified collaborative experience.
          </p>
        </div>
      </div>

      {/* Context Switching Severity */}
      <div className="flex flex-col gap-3">
        <h3 className="text-lg font-semibold tracking-tight flex items-center gap-2">
          <ArrowRightLeft className="size-5 text-tint" />
          Context Switching Severity
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-muted rounded-xl p-4">
            <div className="text-3xl font-semibold tracking-tight tabular-nums mb-1">8–12s</div>
            <div className="text-xs text-muted-foreground">Lost per context switch</div>
          </div>
          <div className="bg-muted rounded-xl p-4">
            <div className="text-3xl font-semibold tracking-tight tabular-nums mb-1">15–20×</div>
            <div className="text-xs text-muted-foreground">Switches per hour</div>
          </div>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          This totals 2–4 minutes of lost productivity every hour, significantly disrupting creative flow.
        </p>
      </div>

      {/* Competitor Failures */}
      <div className="flex flex-col gap-3">
        <h3 className="text-lg font-semibold tracking-tight flex items-center gap-2">
          <AlertCircle className="size-5 text-tint" />
          Competitor Platform Failures
        </h3>
        
        <div className="flex flex-col gap-2">
          {/* Zoom/Google Meet */}
          <div className="bg-muted rounded-xl p-4">
            <h4 className="text-sm font-semibold mb-1.5">Zoom / Google Meet</h4>
            <ul className="text-xs text-muted-foreground flex flex-col gap-1 list-disc pl-4">
              <li>No integrated drawing canvas</li>
              <li>Audio-centric notifications only</li>
              <li>Poor ASL video layouts (16:9)</li>
            </ul>
          </div>

          {/* Figma/Miro */}
          <div className="bg-muted rounded-xl p-4">
            <h4 className="text-sm font-semibold mb-1.5">Figma / Miro</h4>
            <ul className="text-xs text-muted-foreground flex flex-col gap-1 list-disc pl-4">
              <li>Requires separate video app</li>
              <li>Chat in different window/tab</li>
              <li>No accessibility features for deaf users</li>
            </ul>
          </div>

          {/* Discord/Slack */}
          <div className="bg-muted rounded-xl p-4">
            <h4 className="text-sm font-semibold mb-1.5">Discord / Slack</h4>
            <ul className="text-xs text-muted-foreground flex flex-col gap-1 list-disc pl-4">
              <li>Screen sharing blocks participant view</li>
              <li>No persistent collaborative canvas</li>
              <li>Audio alerts unreachable for deaf users</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
