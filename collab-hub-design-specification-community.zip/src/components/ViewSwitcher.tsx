import React from 'react';
import { Palette, FileText, Presentation } from 'lucide-react';

export type ViewMode = 'prototype' | 'specification' | 'poster';

interface ViewSwitcherProps {
  value: ViewMode;
  onChange: (mode: ViewMode) => void;
  className?: string;
}

const OPTIONS: { value: ViewMode; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { value: 'prototype', label: 'Workspace', icon: Palette },
  { value: 'specification', label: 'Spec', icon: FileText },
  { value: 'poster', label: 'Poster', icon: Presentation },
];

/**
 * Segmented control for switching between the prototype, the design
 * specification and the poster. Modeled on the iOS/macOS segmented control:
 * one quiet track, a single raised selection, no per-option color.
 */
export function ViewSwitcher({ value, onChange, className = '' }: ViewSwitcherProps) {
  return (
    <div
      role="tablist"
      aria-label="Switch view"
      className={`inline-flex items-center gap-0.5 rounded-full bg-muted p-1 ${className}`}
    >
      {OPTIONS.map(({ value: option, label, icon: Icon }) => {
        const selected = option === value;
        return (
          <button
            key={option}
            type="button"
            role="tab"
            aria-selected={selected}
            onClick={() => onChange(option)}
            className={`inline-flex h-7 items-center gap-1.5 rounded-full px-3 text-[13px] font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
              selected
                ? 'bg-card text-foreground shadow-soft'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Icon className="size-3.5" />
            <span>{label}</span>
          </button>
        );
      })}
    </div>
  );
}
