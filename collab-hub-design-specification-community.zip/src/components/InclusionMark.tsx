import React from 'react';

/**
 * INCLUSION MARK
 *
 * CollabHub's brand symbol. A single circle — the universal shape of a
 * gathering — with a deliberate opening at the top-right so it never
 * closes. The centered dot is the person at the heart of the circle.
 *
 * It reads as "everyone is welcome here," not as a clinical accessibility
 * glyph. Drawn with currentColor so it inherits the surrounding text color
 * and always meets the same contrast ratio as the label beside it.
 */

interface InclusionMarkProps {
  size?: number;
  className?: string;
  title?: string;
}

export function InclusionMark({ size = 24, className, title = 'CollabHub' }: InclusionMarkProps) {
  // r = 13 → circumference ≈ 81.7; leave a ~14-unit opening
  return (
    <svg
      viewBox="0 0 32 32"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label={title}
      focusable="false"
    >
      <circle
        cx="16"
        cy="16"
        r="13"
        fill="none"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        strokeDasharray="67.7 14"
        transform="rotate(-50 16 16)"
      />
      <circle cx="16" cy="16" r="4.5" fill="currentColor" />
    </svg>
  );
}
