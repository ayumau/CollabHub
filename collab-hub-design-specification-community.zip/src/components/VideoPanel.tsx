import React, { useState, useEffect } from 'react';
import { Video, Mic, MicOff, VideoOff, Hand, Volume2 } from 'lucide-react';
import { Button } from './ui/button';

/**
 * VIDEO PANEL COMPONENT
 * 
 * DESIGN DECISIONS:
 * - Vertical stacking for ASL visibility (face + hands in frame)
 * - Larger tiles than traditional video calls for sign language clarity
 * - Visual indicators replace audio cues (speaking, muted, etc.)
 * - Real-time captions overlay on each participant
 * - Persistent presence without requiring full attention
 * 
 * ACCESSIBILITY FEATURES:
 * - Visual "speaking" indicator (pulsing border) replaces audio meters
 * - Caption overlays for each participant
 * - High contrast borders for active speaker
 * - Hand-raise visual indicator
 */

interface Participant {
  id: string;
  name: string;
  isSpeaking: boolean;
  isMuted: boolean;
  videoEnabled: boolean;
  isHandRaised: boolean;
  currentCaption?: string;
}

interface VideoPanelProps {
  visualIndicators: boolean;
  captionsEnabled: boolean;
}

export function VideoPanel({ visualIndicators, captionsEnabled }: VideoPanelProps) {
  const [participants, setParticipants] = useState<Participant[]>([
    {
      id: '1',
      name: 'You',
      isSpeaking: false,
      isMuted: false,
      videoEnabled: true,
      isHandRaised: false,
    },
    {
      id: '2',
      name: 'Sarah Chen',
      isSpeaking: false,
      isMuted: false,
      videoEnabled: true,
      isHandRaised: false,
      currentCaption: 'I think we should move the button here'
    },
    {
      id: '3',
      name: 'Marcus Johnson',
      isSpeaking: false,
      isMuted: false,
      videoEnabled: true,
      isHandRaised: false,
    },
    {
      id: '4',
      name: 'Alex Rivera',
      isSpeaking: false,
      isMuted: true,
      videoEnabled: true,
      isHandRaised: false,
    },
  ]);

  // Simulate speaking activity
  useEffect(() => {
    const interval = setInterval(() => {
      setParticipants(prev => prev.map(p => {
        if (p.id === '2' && Math.random() > 0.6) {
          return { ...p, isSpeaking: !p.isSpeaking };
        }
        return { ...p, isSpeaking: false };
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-card rounded-2xl shadow-soft flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Video className="size-4 text-signal-video" />
          <span className="text-sm font-semibold">Video</span>
        </div>
        <span className="text-xs text-muted-foreground">{participants.length} participants</span>
      </div>

      {/* Participant Grid - Optimized for ASL visibility */}
      <div className="flex-1 p-3 flex flex-col gap-3 overflow-y-auto">
        {participants.map((participant) => (
          <div
            key={participant.id}
            className={`
              relative aspect-[3/4] bg-muted rounded-xl overflow-hidden shrink-0
              transition-all duration-200
              ${participant.isSpeaking && visualIndicators
                ? 'ring-[3px] ring-signal-video shadow-[0_0_0_6px_rgba(64,156,255,0.18)]' 
                : 'ring-1 ring-white/[0.06]'
              }
              ${participant.isHandRaised ? 'ring-2 ring-signal-attention' : ''}
            `}
          >
            {/* Video placeholder - In production, this would be actual video feed */}
            <div className="w-full h-full bg-gradient-to-b from-[#2c2c2e] to-[#1c1c1e] flex items-center justify-center">
              {participant.videoEnabled ? (
                <div className="text-center">
                  <div className="w-14 h-14 rounded-full bg-accent flex items-center justify-center mb-2 mx-auto ring-1 ring-white/10">
                    <span className="text-xl font-medium text-foreground">{participant.name.charAt(0)}</span>
                  </div>
                </div>
              ) : (
                <VideoOff className="size-8 text-muted-foreground" />
              )}
            </div>

            {/* Visual Speaking Indicator - Replaces audio meters */}
            {visualIndicators && participant.isSpeaking && (
              <div className="absolute top-2 right-2 flex items-center gap-1 bg-primary text-primary-foreground px-2 py-1 rounded-full">
                <Volume2 className="size-3" />
                <span className="text-xs font-medium">Speaking</span>
              </div>
            )}

            {/* Hand Raised Indicator */}
            {participant.isHandRaised && (
              <div className="absolute top-2 left-2 bg-signal-attention text-background p-1.5 rounded-full">
                <Hand className="size-3" />
              </div>
            )}

            {/* Real-time Captions Overlay */}
            {captionsEnabled && participant.currentCaption && (
              <div className="absolute bottom-10 left-2 right-2 bg-background/85 backdrop-blur-md px-2.5 py-1.5 rounded-lg">
                <p className="text-xs leading-snug">{participant.currentCaption}</p>
              </div>
            )}

            {/* Participant Info Bar */}
            <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
              <span className="text-xs font-medium px-2 py-1 bg-background/70 backdrop-blur-md rounded-md">
                {participant.name}
              </span>
              <div className="flex items-center gap-1">
                {participant.isMuted && (
                  <div className="p-1 bg-destructive rounded-md" title="Muted">
                    <MicOff className="size-3 text-destructive-foreground" />
                    <span className="sr-only">Muted</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Control Bar */}
      <div className="p-3 border-t border-border flex items-center justify-center gap-2">
        <Button size="sm" variant="outline" className="rounded-full size-9 p-0" aria-label="Microphone">
          <Mic className="size-4" />
        </Button>
        <Button size="sm" variant="outline" className="rounded-full size-9 p-0" aria-label="Camera">
          <Video className="size-4" />
        </Button>
        <Button size="sm" variant="outline" className="rounded-full size-9 p-0" aria-label="Raise hand" title="Raise hand">
          <Hand className="size-4" />
        </Button>
      </div>
    </div>
  );
}
