import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, Hand } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { HandSignedEmojiPicker } from './HandSignedEmojiPicker';

/**
 * CHAT PANEL COMPONENT WITH HAND-SIGNED EMOJI INTEGRATION
 * 
 * HAND-SIGNED EMOJI SYSTEM SPECIFICATION:
 * 
 * Technical Implementation:
 * - Gesture recognition via MediaPipe Hands (when camera enabled)
 * - Fallback to visual picker for accessibility
 * - Real-time detection with 95%+ accuracy requirement
 * - 200ms max latency for recognition
 * 
 * Cultural Considerations (Deaf Community):
 * - ASL alphabet and common signs as base gesture set
 * - Community-validated emoji mappings
 * - Customizable for regional sign language variations (BSL, Auslan, etc.)
 * - Respectful representation avoiding appropriation
 * 
 * Display Integration:
 * - Larger emoji size (2x standard) for visibility
 * - Animation showing the hand sign gesture
 * - Text label for accessibility and learning
 * - Grouped in chat for emphasis
 * 
 * UX Flow:
 * 1. User clicks hand-signed emoji button
 * 2. Camera activates (with permission) OR visual picker shows
 * 3. User performs sign OR selects from picker
 * 4. System recognizes and confirms with visual feedback
 * 5. Emoji sends to chat with animation
 * 6. Recipients see both the emoji and gesture animation
 */

interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: Date;
  type: 'text' | 'hand-emoji';
  handSign?: {
    emoji: string;
    signName: string;
    animationUrl?: string;
  };
}

interface ChatPanelProps {
  visualIndicators: boolean;
}

export function ChatPanel({ visualIndicators }: ChatPanelProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'Sarah Chen',
      content: 'Love this direction!',
      timestamp: new Date(Date.now() - 120000),
      type: 'text',
    },
    {
      id: '2',
      sender: 'Sarah Chen',
      content: '👍',
      timestamp: new Date(Date.now() - 115000),
      type: 'hand-emoji',
      handSign: {
        emoji: '👍',
        signName: 'Thumbs Up',
      }
    },
    {
      id: '3',
      sender: 'Marcus Johnson',
      content: 'Can we adjust the color palette?',
      timestamp: new Date(Date.now() - 60000),
      type: 'text',
    },
    {
      id: '4',
      sender: 'You',
      content: 'Let me try something...',
      timestamp: new Date(Date.now() - 30000),
      type: 'text',
    },
  ]);

  const [inputValue, setInputValue] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isTyping, setIsTyping] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Simulate typing indicator
  useEffect(() => {
    const timeout = setTimeout(() => {
      if (Math.random() > 0.7) {
        setIsTyping('Alex Rivera');
        setTimeout(() => setIsTyping(null), 3000);
      }
    }, 5000);

    return () => clearTimeout(timeout);
  }, [messages]);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      sender: 'You',
      content: inputValue,
      timestamp: new Date(),
      type: 'text',
    };

    setMessages(prev => [...prev, newMessage]);
    setInputValue('');
  };

  const handleSendHandEmoji = (emoji: string, signName: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      sender: 'You',
      content: emoji,
      timestamp: new Date(),
      type: 'hand-emoji',
      handSign: {
        emoji,
        signName,
      }
    };

    setMessages(prev => [...prev, newMessage]);
    setShowEmojiPicker(false);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  };

  return (
    <div className="bg-card rounded-2xl shadow-soft flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="size-4 text-signal-chat" />
          <span className="text-sm font-semibold">Chat</span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowEmojiPicker(!showEmojiPicker)}
          className="gap-1.5 rounded-full text-tint hover:text-tint"
          aria-expanded={showEmojiPicker}
          title="Hand-Signed Emoji Picker"
        >
          <Hand className="size-4" />
          <span className="text-xs font-medium">Sign</span>
        </Button>
      </div>

      {/* Hand-Signed Emoji Picker */}
      {showEmojiPicker && (
        <div className="border-b border-border">
          <HandSignedEmojiPicker 
            onSelectEmoji={handleSendHandEmoji}
            onClose={() => setShowEmojiPicker(false)}
          />
        </div>
      )}

      {/* Messages Area */}
      <div className="flex-1 p-4 overflow-y-auto flex flex-col gap-4" role="log" aria-live="polite">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex flex-col ${
              message.sender === 'You' ? 'items-end' : 'items-start'
            }`}
          >
            {/* Sender name and timestamp */}
            <div className="flex items-center gap-2 mb-1 px-1">
              <span className="text-xs font-medium text-muted-foreground">{message.sender}</span>
              <span className="text-xs text-muted-foreground">{formatTime(message.timestamp)}</span>
            </div>

            {/* Message bubble */}
            {message.type === 'text' ? (
              <div
                className={`
                  px-3.5 py-2 max-w-[85%]
                  ${message.sender === 'You'
                    ? 'bg-primary text-primary-foreground rounded-2xl rounded-br-md'
                    : 'bg-muted text-foreground rounded-2xl rounded-bl-md'
                  }
                `}
              >
                <p className="text-sm break-words leading-relaxed">{message.content}</p>
              </div>
            ) : (
              // Hand-Signed Emoji - Larger, animated, with label
              <div
                className={`
                  px-5 py-3 rounded-2xl
                  ${message.sender === 'You'
                    ? 'bg-primary text-primary-foreground rounded-br-md'
                    : 'bg-muted text-foreground rounded-bl-md'
                  }
                  flex flex-col items-center gap-1
                  animate-in zoom-in-95 fade-in duration-300
                `}
              >
                <div className="text-4xl leading-none" aria-hidden="true">
                  {message.handSign?.emoji}
                </div>
                <span className="text-xs font-medium">
                  {message.handSign?.signName}
                </span>
                {visualIndicators && (
                  <span className="mt-0.5 px-2 py-0.5 rounded-full text-[11px] font-medium bg-background/20 uppercase tracking-wide">
                    Hand-Signed
                  </span>
                )}
              </div>
            )}
          </div>
        ))}

        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex items-center gap-2 text-muted-foreground">
            <span className="text-xs">{isTyping} is typing</span>
            <div className="flex gap-1" aria-hidden="true">
              <div className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <div className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <div className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-3 border-t border-border">
        <div className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.nativeEvent.isComposing && e.keyCode !== 229) handleSendMessage();
            }}
            placeholder="Message"
            aria-label="Message"
            className="flex-1 rounded-full bg-input-background border-input px-4"
          />
          <Button
            size="sm"
            onClick={handleSendMessage}
            disabled={!inputValue.trim()}
            className="rounded-full size-9 p-0"
            aria-label="Send message"
          >
            <Send className="size-4" />
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2 px-1">
          Use hand-signed emojis for culturally authentic expression
        </p>
      </div>
    </div>
  );
}
