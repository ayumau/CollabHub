import React from 'react';
import { ProblemContext } from './poster/ProblemContext';
import { ResearchInsights } from './poster/ResearchInsights';
import { ProcessPrototypes } from './poster/ProcessPrototypes';
import { InclusionMark } from './InclusionMark';
import { Zap, Shield, Users, Video, Palette, Hand } from 'lucide-react';

/**
 * CollabHub Research Poster
 * Presentation-style layout highlighting problems with competitor platforms
 * and showcasing CollabHub's accessibility-first solution
 */
export function CollabHubPoster() {
  return (
    <div className="min-h-screen bg-background p-8 overflow-y-auto">
      <div className="max-w-[1400px] mx-auto flex flex-col gap-6">
        {/* Header Section */}
        <header className="bg-card rounded-3xl shadow-soft px-12 py-14 text-center">
          <div className="flex flex-col items-center gap-6">
            <InclusionMark size={64} className="text-tint" />

            <div className="flex flex-col items-center gap-3">
              <span className="text-xs font-semibold uppercase tracking-[0.14em] text-tint">
                Accessibility-First Collaboration
              </span>
              <h1 className="text-7xl font-semibold tracking-[-0.03em] text-foreground leading-none">
                CollabHub
              </h1>
            </div>

            <p className="text-2xl text-foreground/90 max-w-3xl mx-auto leading-snug text-balance font-medium tracking-tight">
              Eliminating Context Switching Through Unified Video, Canvas, and Chat
            </p>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance -mt-2">
              Designed for Deaf and Hard-of-Hearing Users with ASL-Optimized Layouts
            </p>
          </div>
        </header>

        {/* Three-Panel Layout */}
        <div className="grid grid-cols-3 gap-6">
          {/* Left Panel: Problem and Context */}
          <section className="bg-card rounded-3xl shadow-soft p-8">
            <ProblemContext />
          </section>

          {/* Center Panel: Research Insights */}
          <section className="bg-card rounded-3xl shadow-soft p-8">
            <ResearchInsights />
          </section>

          {/* Right Panel: Process & Prototypes */}
          <section className="bg-card rounded-3xl shadow-soft p-8">
            <ProcessPrototypes />
          </section>
        </div>

        {/* Bottom Section: Solution Overview */}
        <section className="bg-card rounded-3xl shadow-soft p-10">
          <h2 className="text-3xl font-semibold tracking-tight mb-10 text-center">CollabHub Key Features</h2>
          <div className="grid grid-cols-3 gap-8 mb-10">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="size-16 rounded-full bg-muted flex items-center justify-center">
                <Video className="size-7 text-signal-video" />
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="text-xl font-semibold tracking-tight">Integrated Video</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  ASL-optimized 4:3 layouts with visual indicators replacing audio cues. Active speaker borders and real-time captions ensure accessibility.
                </p>
              </div>
            </div>
            <div className="flex flex-col items-center text-center gap-4">
              <div className="size-16 rounded-full bg-muted flex items-center justify-center">
                <Palette className="size-7 text-signal-canvas" />
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="text-xl font-semibold tracking-tight">Collaborative Canvas</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Real-time drawing tools maintain creative momentum without switching apps. All participants see updates instantly.
                </p>
              </div>
            </div>
            <div className="flex flex-col items-center text-center gap-4">
              <div className="size-16 rounded-full bg-muted flex items-center justify-center">
                <Hand className="size-7 text-signal-chat" />
              </div>
              <div className="flex flex-col gap-2">
                <h3 className="text-xl font-semibold tracking-tight">Hand-Signed Emojis</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  MediaPipe-powered ASL gesture recognition converts authentic sign language to animated emojis for culturally sensitive expression.
                </p>
              </div>
            </div>
          </div>

          {/* Impact Stats */}
          <div className="grid grid-cols-3 gap-6 pt-8 border-t border-border">
            <div className="flex flex-col items-center text-center gap-1">
              <div className="flex items-center gap-2">
                <Zap className="size-5 text-tint" />
                <div className="text-4xl font-semibold tracking-tight tabular-nums">0</div>
              </div>
              <div className="text-sm text-muted-foreground">Context Switches Required</div>
            </div>
            <div className="flex flex-col items-center text-center gap-1">
              <div className="flex items-center gap-2">
                <Shield className="size-5 text-tint" />
                <div className="text-4xl font-semibold tracking-tight">AA</div>
              </div>
              <div className="text-sm text-muted-foreground">WCAG 2.1 Level Compliance</div>
            </div>
            <div className="flex flex-col items-center text-center gap-1">
              <div className="flex items-center gap-2">
                <Users className="size-5 text-tint" />
                <div className="text-4xl font-semibold tracking-tight">3-in-1</div>
              </div>
              <div className="text-sm text-muted-foreground">Unified Communication Tools</div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
