import React, { useState, useEffect } from 'react';
import { Video, MessageSquare, Palette, Activity } from 'lucide-react';

/**
 * USER PRESENCE COMPONENT
 * 
 * UNIVERSAL PRESENCE SYSTEM:
 * Shows real-time activity across all three mediums simultaneously
 * 
 * PRESENCE INDICATORS:
 * - Video: When user's camera/mic is active
 * - Chat: When user is typing or sent recent message
 * - Canvas: When user is actively drawing
 * 
 * BENEFITS:
 * - Team awareness without context switching
 * - Visual activity indicators (no audio needed)
 * - Reduces "where is everyone?" confusion
 * - Encourages engagement through visible participation
 * 
 * ACCESSIBILITY:
 * - Color + icon + text (triple redundancy)
 * - High contrast indicators
 * - Screen reader announcements
 */

interface UserActivity {
  id: string;
  name: string;
  color: string;
  avatar: string;
  activities: {
    video: boolean;
    chat: boolean;
    canvas: boolean;
  };
  lastAction: string;
  timestamp: Date;
}

export function UserPresence() {
  const [users, setUsers] = useState<UserActivity[]>([
    {
      id: '1',
      name: 'You',
      color: '#409cff',
      avatar: 'Y',
      activities: { video: true, chat: false, canvas: true },
      lastAction: 'Drawing on canvas',
      timestamp: new Date()
    },
    {
      id: '2',
      name: 'Sarah Chen',
      color: '#30d158',
      avatar: 'S',
      activities: { video: true, chat: true, canvas: false },
      lastAction: 'Sent a message',
      timestamp: new Date(Date.now() - 5000)
    },
    {
      id: '3',
      name: 'Marcus Johnson',
      color: '#ffd60a',
      avatar: 'M',
      activities: { video: true, chat: false, canvas: true },
      lastAction: 'Drawing on canvas',
      timestamp: new Date(Date.now() - 10000)
    },
    {
      id: '4',
      name: 'Alex Rivera',
      color: '#bf5af2',
      avatar: 'A',
      activities: { video: true, chat: false, canvas: false },
      lastAction: 'Watching',
      timestamp: new Date(Date.now() - 30000)
    }
  ]);

  // Simulate activity changes
  useEffect(() => {
    const interval = setInterval(() => {
      setUsers(prev => prev.map(user => {
        if (user.id === '1') return user; // Don't change current user
        
        const actions = ['video', 'chat', 'canvas'] as const;
        const randomAction = actions[Math.floor(Math.random() * actions.length)];
        
        return {
          ...user,
          activities: {
            ...user.activities,
            [randomAction]: Math.random() > 0.5
          },
          lastAction: randomAction === 'video' ? 'Speaking' 
            : randomAction === 'chat' ? 'Typing...' 
            : 'Drawing',
          timestamp: new Date()
        };
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const getTimeAgo = (date: Date) => {
    const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
    if (seconds < 10) return 'just now';
    if (seconds < 60) return `${seconds}s ago`;
    return `${Math.floor(seconds / 60)}m ago`;
  };

  return (
    <footer className="bg-background/80 backdrop-blur-xl border-t border-border px-5 py-2.5">
      <div className="flex items-center gap-4 overflow-x-auto">
        {/* Label */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <Activity className="size-4 text-tint" />
          <span className="text-xs font-medium text-muted-foreground">Live Activity</span>
        </div>

        {/* User Activity Cards */}
        <div className="flex gap-2 flex-1">
          {users.map(user => (
            <div
              key={user.id}
              className="flex items-center gap-2.5 pl-1.5 pr-3 py-1.5 bg-card rounded-full shadow-soft flex-shrink-0 transition-colors hover:bg-muted"
            >
              {/* Avatar with status ring */}
              <div className="relative">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium bg-muted text-foreground"
                  style={{ boxShadow: `inset 0 0 0 2px ${user.color}` }}
                >
                  {user.avatar}
                </div>
                {/* Active indicator */}
                {(user.activities.video || user.activities.chat || user.activities.canvas) && (
                  <div 
                    className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full ring-2 ring-card"
                    style={{ backgroundColor: user.color }}
                  />
                )}
              </div>

              {/* User info */}
              <div className="flex flex-col min-w-[120px]">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-medium leading-tight">{user.name}</span>
                  {/* Activity icons */}
                  <div className="flex gap-1">
                    {user.activities.video && (
                      <Video className="size-3 text-signal-video" aria-label="In video call" />
                    )}
                    {user.activities.chat && (
                      <MessageSquare className="size-3 text-signal-chat" aria-label="Active in chat" />
                    )}
                    {user.activities.canvas && (
                      <Palette className="size-3 text-signal-canvas" aria-label="Drawing on canvas" />
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground leading-tight">
                  <span>{user.lastAction}</span>
                  <span aria-hidden="true">·</span>
                  <span>{getTimeAgo(user.timestamp)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Summary Stats */}
        <div className="flex items-center gap-4 flex-shrink-0 pl-4 border-l border-border text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Video className="size-3.5 text-signal-video" />
            <span>{users.filter(u => u.activities.video).length}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <MessageSquare className="size-3.5 text-signal-chat" />
            <span>{users.filter(u => u.activities.chat).length}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Palette className="size-3.5 text-signal-canvas" />
            <span>{users.filter(u => u.activities.canvas).length}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
